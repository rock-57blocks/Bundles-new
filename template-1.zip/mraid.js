/**
* Optional MRAID identification tag for SDK.
* @module "vungle"
*/

/**
* @function*
* @param {Object} window - window object
*/
(function (window) {
    "use strict";

    window.vungle = window.vungle || {};

})(window);
